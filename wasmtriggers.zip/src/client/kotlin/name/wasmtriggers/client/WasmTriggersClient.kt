package name.wasmtriggers.client

import net.fabricmc.api.ClientModInitializer

object WasmTriggersClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}